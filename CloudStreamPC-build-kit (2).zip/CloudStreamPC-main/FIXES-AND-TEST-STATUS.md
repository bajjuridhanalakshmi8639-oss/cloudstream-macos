# CloudStreamPC source patch — consolidated status

This archive is **source code, not a built or runtime-verified macOS app/DMG**. The repository source version is 3.0.10; the user's currently installed app reports 3.0.2. The installed app is not changed by downloading this ZIP.

## Changes included

### Extension install lifecycle and recovery
- Extension install work now starts in an application-owned `CoroutineScope(SupervisorJob + Dispatchers.IO)`, not in the Extensions screen's `rememberCoroutineScope`. The install task continues if the user navigates away; the UI only awaits the result and rethrows ordinary UI cancellation rather than displaying `rememberCoroutineScope left the composition` as an installation failure.
- Concurrent requests for the same extension share one in-flight installation task. First-launch batch setup starts all tasks in the app scope before awaiting them, Compose cancellation is no longer shown as an install error, and cancellable manager loops preserve cancellation rather than swallowing it as a normal failure.
- A successful install/uninstall bumps an observable install revision so the home screen refreshes after an install completes in the background.
- Downloads stream to a temporary file (64 KiB buffer) instead of materializing the whole HTTP body in heap; cancellation is checked during transfer and a 100 MiB cap is enforced while bytes are received, even if Content-Length is missing or incorrect.
- Temporary and restored extension archives must contain `manifest.json` and at least one supported `classes*.dex` entry before they are accepted.
- The previous `.cs3` file is retained as a backup until the new version has converted and loaded successfully. If conversion/load fails, the new file is removed, prior settings/file are restored where possible, and the previous extension is reloaded.
- Per-extension load failures are isolated; partial provider/extractor registration and class loaders are cleaned up. The UI shows the actual failure reason.

### DEX conversion and memory
- Extension download and archive SHA-256 hashing stream files rather than duplicating the entire response/archive in heap.
- Install validation rejects more than 8 DEX entries, over 32 MiB per DEX or over 64 MiB total DEX payload before replacing the prior extension. Conversion repeats the same limits as a second guard.
- Before conversion, the app performs a best-effort GC and estimates a conservative working set (`10 × raw DEX payload + 192 MiB`). It rejects conversion when the estimated allocation cannot fit in the current/max heap, rather than intentionally exhausting the heap and taking down Compose.
- On an `OutOfMemoryError`, the failed conversion cache is removed and a concise memory diagnostic is logged instead of dumping a large stack trace in the OOM path.
- The packaged app's maximum heap is set to 2 GiB. This can use more RAM; it is not a guarantee that every extension will fit.
- macOS player settings no longer label mpv as bundled on Mac, and the missing-player message gives Apple Silicon/Homebrew guidance. Auto-detection already checks `/opt/homebrew/bin/mpv`, `/usr/local/bin/mpv`, and `/Applications/mpv.app/Contents/MacOS/mpv`.

### Android extension compatibility
- A desktop `Context.getSharedPreferences(String, int)` / `SharedPreferences` shim is included for common preference calls. Its JVM descriptor was checked independently with `kotlinc` + `javap` and matches `(Ljava/lang/String;I)Landroid/content/SharedPreferences;`.
- Preferences now persist under `CloudStreamPC/extension-preferences` using per-name hashed files and atomic replacement. Strings, string sets, integer/long/float/boolean values survive application restarts; reads tolerate a corrupt preference file by falling back to defaults. This is a compatibility subset, not a full Android runtime.
- Missing Android/AndroidX methods/classes now report more specific compatibility diagnostics. `StremioX`'s `androidx.fragment.app.DialogFragment` dependency is still **not supported**: a fake placeholder would not implement Android Fragment UI/lifecycle and would be unsafe. That extension needs a desktop-compatible implementation or a real compatibility layer.
- The preference shim is still not a full Android API emulator; Android UI, Fragment lifecycle, services, intents and other unsupported framework APIs are not emulated.

### Other prior fixes retained
- Search generations prevent stale query results overwriting newer results; clearing search cancels/invalidate the old job; provider searches have a timeout and merged error details.
- Startup extension health checks do not auto-open browser/CAPTCHA prompts; checks remain manual and CAPTCHA prompts have a per-host cooldown.
- First-launch batch setup records per-extension errors instead of silently marking failed setup complete.

## Verification performed in this environment

- `PluginManager.kt` compiled with the installed Kotlin compiler against minimal API stubs and the available coroutines library. This is a **syntax/type sanity check for the edited manager only**, not a full project compile.
- A coroutine smoke test cancelled the UI waiter after installation started and confirmed the application-owned install task still completed.
- A rollback smoke test using minimal API stubs and a deliberately failing fake provider confirmed that the previous `.cs3` bytes and installed-version metadata are restored.
- `android/content/Context.kt` compiled standalone; `javap -s` confirmed the expected `getSharedPreferences` JVM descriptor.
- `scripts/test-context-preferences.sh` passed a two-process persistence smoke test for strings (including non-ASCII), numeric/boolean values, and sets containing empty strings/commas; the method descriptor assertion passed.
- `python3 scripts/verify-source-patch.py`: all dependency-free static assertions passed.
- ZIP integrity (`unzip -t`) passes for the delivered archive.

## Build on the target Apple Silicon Mac

From the extracted project folder on macOS with JDK 21 installed and network access available:

```bash
chmod +x scripts/build-macos-dmg.sh
./scripts/build-macos-dmg.sh
```

The script runs project tests and the Gradle `packageDmg` task. If successful, it prints the `.dmg` path beneath `build/compose/binaries/main/dmg/`. It intentionally refuses to run on Linux because the macOS app image must be packaged on macOS.

## Blockers / not verified

- The full Gradle build and project tests are **not successful/verified**: `./gradlew --version` fails while resolving `services.gradle.org` with `UnknownHostException`. This environment has no cached Gradle 8.14.3 distribution or Maven artifacts to build offline. `scripts/build-macos-dmg.sh` is included to run `clean test packageDmg` on the user's Mac, where a macOS `.dmg` can actually be packaged.
- Because there is no successful application build here, the shim has not been confirmed inside a packaged application, and the user's installed 3.0.2 runtime cannot receive these source changes directly.
- `rememberCoroutineScope` is addressed at extension-install lifecycle boundaries and first-launch batch installation in source, but the original app error has not been reproduced against the rebuilt application.
- CineStream provider visibility, non-Bigg-Boss searches, source extraction, video playback/mpv integration, Cloudflare prompts and macOS runtime stability are not tested in the rebuilt application. The player-path UI/help has been corrected, but actual playback still requires a rebuilt app and macOS test.
- The `StremioAddon` `NoSuchMethodError` should be addressed by the new desktop shim once a new build includes it, but runtime confirmation requires a successful build and the actual add-on. `StremioX`'s missing AndroidX Fragment class remains unsupported as described above.

Do not treat this source ZIP as a finished installer. A full build and runtime validation on macOS are still required before calling the app fixed.

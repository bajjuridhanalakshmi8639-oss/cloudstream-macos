package android.content

import com.cloudstreampc.core.AppDirs
import java.io.File
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.Base64
import java.util.Properties
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Minimal desktop stand-in for Android Context. Only APIs implemented here are safe to use
 * from extensions; Android UI/lifecycle APIs are intentionally not emulated.
 */
open class Context {
    /** Android-compatible method descriptor used by many simple extensions. */
    open fun getSharedPreferences(name: String, mode: Int): SharedPreferences =
        DesktopPreferencesStore.get(name)

    companion object {
        const val MODE_PRIVATE: Int = 0
    }
}

/** Desktop compatibility subset of Android's SharedPreferences API. */
interface SharedPreferences {
    fun getAll(): Map<String, *>
    fun getString(key: String, defValue: String?): String?
    fun getStringSet(key: String, defValues: Set<String>?): Set<String>?
    fun getInt(key: String, defValue: Int): Int
    fun getLong(key: String, defValue: Long): Long
    fun getFloat(key: String, defValue: Float): Float
    fun getBoolean(key: String, defValue: Boolean): Boolean
    fun contains(key: String): Boolean
    fun edit(): Editor
    fun registerOnSharedPreferenceChangeListener(listener: OnSharedPreferenceChangeListener?)
    fun unregisterOnSharedPreferenceChangeListener(listener: OnSharedPreferenceChangeListener?)

    interface Editor {
        fun putString(key: String, value: String?): Editor
        fun putStringSet(key: String, values: Set<String>?): Editor
        fun putInt(key: String, value: Int): Editor
        fun putLong(key: String, value: Long): Editor
        fun putFloat(key: String, value: Float): Editor
        fun putBoolean(key: String, value: Boolean): Editor
        fun remove(key: String): Editor
        fun clear(): Editor
        fun commit(): Boolean
        fun apply()
    }

    fun interface OnSharedPreferenceChangeListener {
        fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String?)
    }
}

/**
 * Returns one preference object per name and stores simple preference values on disk. Android
 * extensions commonly expect preferences to survive a process restart; an in-memory-only shim
 * made account/session settings appear to disappear every time CloudStreamPC was reopened.
 */
private object DesktopPreferencesStore {
    private val instances = ConcurrentHashMap<String, DesktopSharedPreferences>()
    fun get(name: String): SharedPreferences = instances.computeIfAbsent(name) { DesktopSharedPreferences(it) }
}

private class DesktopSharedPreferences(private val name: String) : SharedPreferences {
    private val file: File by lazy {
        val directory = File(AppDirs.root, "extension-preferences").apply { mkdirs() }
        val digest = MessageDigest.getInstance("SHA-256").digest(name.toByteArray(StandardCharsets.UTF_8))
        File(directory, digest.joinToString("") { "%02x".format(it) } + ".properties")
    }
    private val values = ConcurrentHashMap<String, Any>().apply { putAll(readFromDisk()) }
    private val listeners = CopyOnWriteArraySet<SharedPreferences.OnSharedPreferenceChangeListener>()

    override fun getAll(): Map<String, *> = synchronized(values) { HashMap(values) }
    override fun getString(key: String, defValue: String?) = (values[key] as? String) ?: defValue
    @Suppress("UNCHECKED_CAST")
    override fun getStringSet(key: String, defValues: Set<String>?) = (values[key] as? Set<String>)?.toSet() ?: defValues
    override fun getInt(key: String, defValue: Int) = (values[key] as? Int) ?: defValue
    override fun getLong(key: String, defValue: Long) = (values[key] as? Long) ?: defValue
    override fun getFloat(key: String, defValue: Float) = (values[key] as? Float) ?: defValue
    override fun getBoolean(key: String, defValue: Boolean) = (values[key] as? Boolean) ?: defValue
    override fun contains(key: String) = values.containsKey(key)

    override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) listeners.add(listener)
    }

    override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        if (listener != null) listeners.remove(listener)
    }

    override fun edit(): SharedPreferences.Editor = DesktopEditor()

    private inner class DesktopEditor : SharedPreferences.Editor {
        private val pending = LinkedHashMap<String, Any?>()
        private var clear = false

        override fun putString(key: String, value: String?) = applyValue(key, value)
        override fun putStringSet(key: String, values: Set<String>?) = applyValue(key, values?.toSet())
        override fun putInt(key: String, value: Int) = applyValue(key, value)
        override fun putLong(key: String, value: Long) = applyValue(key, value)
        override fun putFloat(key: String, value: Float) = applyValue(key, value)
        override fun putBoolean(key: String, value: Boolean) = applyValue(key, value)
        private fun applyValue(key: String, value: Any?): SharedPreferences.Editor {
            pending[key] = value
            return this
        }
        override fun remove(key: String): SharedPreferences.Editor {
            pending[key] = Removed
            return this
        }
        override fun clear(): SharedPreferences.Editor {
            clear = true
            return this
        }
        override fun commit(): Boolean = applyChanges()
        override fun apply() { applyChanges() }

        private fun applyChanges(): Boolean {
            val changed = linkedSetOf<String>()
            val persisted: Boolean
            synchronized(values) {
                if (clear) {
                    changed += values.keys
                    values.clear()
                }
                pending.forEach { (key, value) ->
                    val old = values[key]
                    when {
                        value === Removed || value == null -> {
                            if (values.remove(key) != null) changed += key
                        }
                        old != value -> {
                            values[key] = value
                            changed += key
                        }
                    }
                }
                persisted = try {
                    writeToDisk()
                    true
                } catch (_: Exception) {
                    false
                }
            }
            changed.forEach { key ->
                listeners.forEach { listener ->
                    runCatching { listener.onSharedPreferenceChanged(this@DesktopSharedPreferences, key) }
                }
            }
            return persisted
        }
    }

    private fun readFromDisk(): Map<String, Any> {
        val target = file
        if (!target.isFile) return emptyMap()
        val properties = Properties()
        return try {
            target.inputStream().buffered().use(properties::load)
            buildMap {
                properties.stringPropertyNames().forEach { key ->
                    decode(properties.getProperty(key))?.let { put(key, it) }
                }
            }
        } catch (_: Exception) {
            // A partially written/old preference file must never prevent the extension from loading.
            emptyMap()
        }
    }

    @Throws(IOException::class)
    private fun writeToDisk() {
        val properties = Properties()
        values.forEach { (key, value) -> properties.setProperty(key, encode(value)) }
        val target = file
        target.parentFile?.mkdirs()
        val temporary = File(target.parentFile, "${target.name}.tmp-${System.nanoTime()}")
        try {
            temporary.outputStream().buffered().use { properties.store(it, "CloudStreamPC desktop extension preferences") }
            try {
                Files.move(temporary.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (_: IOException) {
                Files.move(temporary.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
            }
        } finally {
            temporary.delete()
        }
    }

    private fun encode(value: Any): String = when (value) {
        is String -> "s:" + b64(value)
        is Int -> "i:$value"
        is Long -> "l:$value"
        is Float -> "f:$value"
        is Boolean -> "b:$value"
        is Set<*> -> "ss:" + value.filterIsInstance<String>().joinToString(",") { "~" + b64(it) }
        else -> "s:" + b64(value.toString())
    }

    private fun decode(value: String): Any? = runCatching {
        when {
            value.startsWith("s:") -> unb64(value.substring(2))
            value.startsWith("i:") -> value.substring(2).toInt()
            value.startsWith("l:") -> value.substring(2).toLong()
            value.startsWith("f:") -> value.substring(2).toFloat()
            value.startsWith("b:") -> value.substring(2).toBooleanStrict()
            value.startsWith("ss:") -> value.substring(3).takeIf { it.isNotEmpty() }
                ?.split(',')?.mapTo(linkedSetOf()) { unb64(it.removePrefix("~")) } ?: emptySet<String>()
            else -> null
        }
    }.getOrNull()

    private fun b64(text: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(text.toByteArray(StandardCharsets.UTF_8))
    private fun unb64(text: String): String = String(Base64.getUrlDecoder().decode(text), StandardCharsets.UTF_8)

    private data object Removed
}

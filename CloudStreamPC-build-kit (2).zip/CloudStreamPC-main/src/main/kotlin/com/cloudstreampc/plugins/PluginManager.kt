package com.cloudstreampc.plugins

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue
import com.cloudstreampc.core.AppDirs
import com.cloudstreampc.core.InstalledPlugin
import com.cloudstreampc.core.Logger
import com.cloudstreampc.core.Store
import com.cloudstreampc.core.mapper
import com.googlecode.d2j.dex.Dex2jar
import com.lagradost.cloudstream3.APIHolder
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.plugins.BasePlugin
import com.lagradost.cloudstream3.plugins.Plugin
import com.lagradost.cloudstream3.utils.extractorApis
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.net.URLClassLoader
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipFile

sealed interface PluginState {
    data object Loaded : PluginState
    data class Failed(val reason: String) : PluginState
}

/**
 * Installs and loads CloudStream extensions (.cs3).
 *
 * A .cs3 is a zip holding `manifest.json` and Android `classes.dex`. On the desktop the
 * DEX is translated once into JVM classes, then loaded with a [URLClassLoader] whose
 * parent is the app's class loader (which provides the CloudStream library).
 */
object PluginManager {
    private val mutex = Mutex()
    private val loaded = mutableMapOf<String, LoadedPlugin>()

    // Install jobs belong to the application, not to an ExtensionsScreen composition.
    // rememberCoroutineScope() is cancelled when the user navigates away; binding a download,
    // file replacement and DEX conversion to that UI scope used to surface the cancellation
    // reason as "rememberCoroutineScope left the composition" and could interrupt an install.
    private val installScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inFlightInstalls = ConcurrentHashMap<String, Deferred<Unit>>()

    /** internalName -> state, observable by the UI. */
    val states = mutableStateMapOf<String, PluginState>()

    /** Bumped whenever providers are added or removed, so the UI can refresh. */
    var revision by mutableIntStateOf(0)
        private set

    /** Changes only after an install/uninstall finishes; home data can refresh if its screen was hidden. */
    var installRevision by mutableIntStateOf(0)
        private set

    /**
     * Prefixes the Android app gives the library at startup: without them `addMalId` and the
     * other sync ids overwrite each other in `syncData`.
     */
    fun configureLibrary() {
        com.lagradost.cloudstream3.LoadResponse.malIdPrefix = "MAL"
        com.lagradost.cloudstream3.LoadResponse.aniListIdPrefix = "AniList"
        com.lagradost.cloudstream3.LoadResponse.kitsuIdPrefix = "Kitsu"
        com.lagradost.cloudstream3.LoadResponse.simklIdPrefix = "Simkl"
    }

    fun notifyProvidersChanged() {
        revision++
    }

    /** All loaded providers; reading it in a composable subscribes to changes. */
    val providers: List<MainAPI>
        get() {
            revision
            return APIHolder.allProviders.toList().sortedBy { it.name.lowercase() }
        }

    private class LoadedPlugin(val instance: BasePlugin, val loader: URLClassLoader, val file: File)

    private fun cs3File(internalName: String) = File(AppDirs.plugins, "${safeName(internalName)}.cs3")
    private fun classesDir(internalName: String) = File(AppDirs.plugins, "${safeName(internalName)}.classes")
    private fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    suspend fun loadInstalled() = withContext(Dispatchers.IO) {
        // A single incompatible or damaged extension must never prevent the rest from loading.
        // Keep each attempt isolated so a failure (including linkage errors) is recorded per plugin.
        for (plugin in Store.settings.installedPlugins) {
            try {
                mutex.withLock { loadLocked(plugin) }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                states[plugin.internalName] = PluginState.Failed(failureSummary(error))
                Logger.error("Échec isolé du chargement de l'extension ${plugin.internalName}", error)
                revision++
            }
        }
    }

    private fun failureSummary(error: Throwable): String = when (error) {
        is OutOfMemoryError -> "Mémoire Java insuffisante pendant la conversion DEX. Désinstallez les extensions inutiles ou utilisez une version plus petite."
        is NoSuchMethodError -> "Extension incompatible avec l'API desktop disponible (${error.message ?: error.javaClass.simpleName}). Une nouvelle build CloudStreamPC avec la couche de compatibilité peut être nécessaire."
        is NoClassDefFoundError -> if (error.message?.contains("androidx/fragment/app/DialogFragment") == true) {
            "Extension incompatible : AndroidX Fragment/DialogFragment n'est pas pris en charge par l'interface desktop. Il faut une version de cette extension adaptée au desktop."
        } else {
            "Classe Android/AndroidX manquante pour cette extension : ${error.message ?: error.javaClass.simpleName}"
        }
        is ClassNotFoundException -> "Classe requise par l'extension absente du runtime desktop : ${error.message ?: error.javaClass.simpleName}"
        else -> error.message ?: error.toString()
    }

    fun startInstall(plugin: SitePlugin, repositoryUrl: String?): Deferred<Unit> {
        val name = safeName(plugin.internalName)
        // Reuse an in-flight install for this extension instead of running two replacements at once.
        // The Deferred is a child of installScope (SupervisorJob), not the caller's UI coroutine.
        val task = inFlightInstalls.computeIfAbsent(name) {
            installScope.async(start = CoroutineStart.LAZY) {
                installTransaction(plugin, repositoryUrl)
            }.also { created ->
                created.invokeOnCompletion { cause ->
                    inFlightInstalls.remove(name, created)
                    if (cause != null && cause !is CancellationException) {
                        // The UI waiter may have left composition. Keep the failure visible in app
                        // state/logs even when nobody is still awaiting the Deferred.
                        if (states[plugin.internalName] !is PluginState.Loaded) {
                            states[plugin.internalName] = PluginState.Failed(failureSummary(cause))
                        }
                        Logger.error("Échec de l'installation de l'extension ${plugin.internalName}", cause)
                        revision++
                    }
                }
            }
        }
        task.start()
        return task
    }

    suspend fun install(plugin: SitePlugin, repositoryUrl: String?) {
        // Convenience API for non-UI callers. Cancelling the caller only cancels await(), not install.
        startInstall(plugin, repositoryUrl).await()
    }

    private suspend fun installTransaction(plugin: SitePlugin, repositoryUrl: String?) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val file = cs3File(plugin.internalName)
            file.parentFile?.mkdirs()
            val tempFile = File(file.parentFile, "${file.name}.download")
            val backupFile = File(file.parentFile, "${file.name}.backup")
            val previousEntry = Store.settings.installedPlugins.firstOrNull { it.internalName == plugin.internalName }

            val declaredSize = plugin.fileSize
            require(declaredSize == null || declaredSize in 1..MAX_EXTENSION_ARCHIVE_BYTES) {
                "Extension trop volumineuse (limite desktop : ${MAX_EXTENSION_ARCHIVE_BYTES / (1024 * 1024)} Mo)"
            }

            try {
                // Stream into a temporary file instead of materializing the whole HTTP response in heap.
                // The byte count is enforced while downloading even if Content-Length is omitted or wrong.
                downloadExtension(plugin.url, tempFile)
                validateExtensionArchive(tempFile)

                // Keep the prior .cs3 until the new version has completed DEX conversion and load().
                // This makes a bad extension update recoverable instead of deleting the last working version.
                unloadLocked(plugin.internalName)
                backupFile.delete()
                val hadOldFile = file.exists()
                if (hadOldFile && !file.renameTo(backupFile)) {
                    previousEntry?.let { loadLocked(it) }
                    error("Impossible de sauvegarder l'extension existante")
                }
                if (!tempFile.renameTo(file)) {
                    val restored = if (backupFile.exists()) backupFile.renameTo(file) else !hadOldFile
                    if (previousEntry != null && restored && file.exists()) loadLocked(previousEntry)
                    error("Impossible d'installer le fichier d'extension; ${if (restored) "version précédente conservée" else "restauration manuelle nécessaire"}")
                }
                classesDir(plugin.internalName).deleteRecursively()

                val entry = InstalledPlugin(
                    internalName = plugin.internalName,
                    name = plugin.name,
                    version = plugin.version,
                    url = plugin.url,
                    repositoryUrl = repositoryUrl,
                    description = plugin.description,
                    language = plugin.language,
                    iconUrl = plugin.iconUrl,
                    authors = plugin.authors,
                )
                try {
                    Store.updateSettings { settings ->
                        settings.copy(installedPlugins = settings.installedPlugins.filterNot { it.internalName == plugin.internalName } + entry)
                    }
                    loadLocked(entry)
                    val loadState = states[plugin.internalName]
                    if (loadState !is PluginState.Loaded) {
                        val why = (loadState as? PluginState.Failed)?.reason ?: "chargement non confirmé"
                        error("L'extension n'a pas pu démarrer : $why")
                    }
                    backupFile.delete()
                    installRevision++
                    Unit
                } catch (failure: Throwable) {
                    // Roll back file + saved metadata when the new extension cannot start.
                    unloadLocked(plugin.internalName)
                    file.delete()
                    classesDir(plugin.internalName).deleteRecursively()
                    val restoredFile = if (backupFile.exists()) backupFile.renameTo(file) else !hadOldFile
                    Store.updateSettings { settings ->
                        val clean = settings.installedPlugins.filterNot { it.internalName == plugin.internalName }
                        settings.copy(installedPlugins = if (previousEntry == null) clean else clean + previousEntry)
                    }
                    if (previousEntry != null && restoredFile && file.exists()) {
                        loadLocked(previousEntry)
                    }
                    // Preserve structured coroutine cancellation after rollback; do not turn it into
                    // a normal installation failure or a user-visible toast.
                    if (failure is CancellationException) throw failure
                    throw IllegalStateException(
                        "Nouvelle version refusée; ${if (previousEntry != null && restoredFile) "version précédente restaurée" else "extension retirée"}. Cause : ${failure.message ?: failure.javaClass.simpleName}",
                        failure,
                    )
                }
            } finally {
                tempFile.delete()
            }
        }
    }

    private const val MAX_EXTENSION_ARCHIVE_BYTES = 100L * 1024 * 1024
    private const val MAX_DEX_COUNT = 8
    private const val MAX_SINGLE_DEX_BYTES = 32L * 1024 * 1024
    private const val MAX_TOTAL_DEX_BYTES = 64L * 1024 * 1024

    private suspend fun downloadExtension(url: String, destination: File) = withContext(Dispatchers.IO) {
        app.get(url, cacheTime = 0).use { response ->
            val body = response.body
            val advertisedSize = body.contentLength()
            require(advertisedSize <= MAX_EXTENSION_ARCHIVE_BYTES) {
                "Archive d'extension trop volumineuse (limite desktop : ${MAX_EXTENSION_ARCHIVE_BYTES / (1024 * 1024)} Mo)"
            }
            var downloaded = 0L
            body.byteStream().use { input ->
                destination.outputStream().buffered().use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        downloaded += count
                        require(downloaded <= MAX_EXTENSION_ARCHIVE_BYTES) {
                            "Archive d'extension trop volumineuse (limite desktop : ${MAX_EXTENSION_ARCHIVE_BYTES / (1024 * 1024)} Mo)"
                        }
                        output.write(buffer, 0, count)
                    }
                }
            }
            require(downloaded > 0L) { "Archive d'extension vide" }
        }
    }

    private fun validateExtensionArchive(file: File) {
        require(file.exists() && file.length() in 1..MAX_EXTENSION_ARCHIVE_BYTES) {
            "Archive d'extension vide ou trop volumineuse"
        }
        ZipFile(file).use { zip ->
            require(zip.getEntry("manifest.json") != null) { "Extension invalide : manifest.json absent" }
            val dexEntries = zip.entries().asSequence()
                .filter { !it.isDirectory && it.name.matches(Regex("classes(?:[0-9]+)?\\.dex")) }
                .toList()
            require(dexEntries.isNotEmpty()) { "Extension invalide : classes.dex absent" }
            require(dexEntries.size <= MAX_DEX_COUNT) {
                "Extension incompatible : plus de $MAX_DEX_COUNT fichiers DEX dans le package desktop"
            }
            val totalDexBytes = dexEntries.sumOf { it.size.coerceAtLeast(0L) }
            require(dexEntries.all { it.size in 1..MAX_SINGLE_DEX_BYTES } && totalDexBytes <= MAX_TOTAL_DEX_BYTES) {
                "Extension trop volumineuse pour la conversion desktop (DEX > 32 Mo par fichier ou > 64 Mo au total)"
            }
        }
    }

    suspend fun uninstall(internalName: String) = withContext(Dispatchers.IO) {
        mutex.withLock {
            unloadLocked(internalName)
            cs3File(internalName).delete()
            classesDir(internalName).deleteRecursively()
            states.remove(internalName)
            Store.updateSettings { s ->
                s.copy(installedPlugins = s.installedPlugins.filterNot { it.internalName == internalName })
            }
            installRevision++
        }
    }

    /** Reinstalls every installed extension whose repository offers a newer version. */
    suspend fun updateAll(): Int {
        var updated = 0
        val byRepo = Store.settings.installedPlugins.groupBy { it.repositoryUrl }
        for ((repoUrl, installed) in byRepo) {
            if (repoUrl == null) continue
            val available = try {
                RepositoryManager.fetchPlugins(repoUrl)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Throwable) {
                Logger.error("Mise à jour impossible pour $repoUrl", error)
                continue
            }
            for (plugin in installed) {
                val remote = available.firstOrNull { it.internalName == plugin.internalName } ?: continue
                if (remote.version > plugin.version) {
                    Logger.info("Mise à jour de ${plugin.name} ${plugin.version} -> ${remote.version}")
                    try {
                        install(remote, repoUrl)
                        updated++
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (error: Throwable) {
                        Logger.error("Échec de la mise à jour de ${plugin.name}", error)
                    }
                }
            }
        }
        return updated
    }

    /** Downloads the installed extensions whose file is missing (after restoring a backup). */
    suspend fun restoreMissing() = withContext(Dispatchers.IO) {
        for (plugin in Store.settings.installedPlugins) {
            if (cs3File(plugin.internalName).exists() && loaded.containsKey(plugin.internalName)) continue
            mutex.withLock {
                try {
                    val target = cs3File(plugin.internalName)
                    if (!target.exists()) {
                        val temp = File(target.parentFile, "${target.name}.restore.download")
                        try {
                            downloadExtension(plugin.url, temp)
                            validateExtensionArchive(temp)
                            require(temp.renameTo(target)) { "Impossible de restaurer le fichier d'extension" }
                        } finally {
                            temp.delete()
                        }
                    }
                    loadLocked(plugin)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Throwable) {
                    Logger.error("Restauration de ${plugin.name}", error)
                }
            }
        }
    }

    private fun loadLocked(plugin: InstalledPlugin) {
        val name = plugin.internalName
        val file = cs3File(name)
        if (loaded.containsKey(name)) return
        var classLoader: URLClassLoader? = null
        try {
            if (!file.exists()) {
                states[name] = PluginState.Failed("Fichier manquant, réinstallez l'extension")
                return
            }
            val dir = ensureConverted(file, classesDir(name))
            val manifest = ZipFile(file).use { zip ->
                val entry = zip.getEntry("manifest.json") ?: error("manifest.json absent")
                zip.getInputStream(entry).use { mapper.readValue(it, BasePlugin.Manifest::class.java) }
            }
            val loader = URLClassLoader(arrayOf(dir.toURI().toURL()), PluginManager::class.java.classLoader)
            classLoader = loader
            val instance = loader.loadClass(manifest.pluginClassName)
                .getDeclaredConstructor().newInstance() as BasePlugin
            instance.filename = file.absolutePath
            // Do not mark the extension as loaded until its initialization has completed.
            // Previously, if load() registered a few providers and then threw, the instance
            // stayed in `loaded`; retries silently returned early and the provider list could
            // remain partially initialized.
            if (instance is Plugin) instance.load(Context()) else instance.load()
            loaded[name] = LoadedPlugin(instance, loader, file)
            states[name] = PluginState.Loaded
            revision++
            val providerCount = APIHolder.allProviders.count { it.sourcePlugin == file.absolutePath }
            val extractorCount = extractorApis.count { it.sourcePlugin == file.absolutePath }
            Logger.info("Extension chargée : ${manifest.name} v${manifest.version} — $providerCount fournisseur(s), $extractorCount extracteur(s)")
        } catch (t: Throwable) {
            val path = file.absolutePath
            if (t is OutOfMemoryError) {
                // The heap is already exhausted. Avoid creating temporary collections or printing
                // a full stack trace here; do only best-effort in-place cleanup and a concise state update.
                System.gc()
                runCatching {
                    APIHolder.allProviders.removeAll { provider ->
                        if (provider.sourcePlugin == path) {
                            runCatching { APIHolder.removePluginMapping(provider) }
                            true
                        } else false
                    }
                    extractorApis.removeAll { it.sourcePlugin == path }
                }
                runCatching { classLoader?.close() }
                runCatching { classesDir(name).deleteRecursively() }
                states[name] = PluginState.Failed(failureSummary(t))
                revision++
                Logger.error("Impossible de charger l'extension $name : mémoire insuffisante pendant la conversion DEX; cache supprimé")
                return
            }
            // A failed extension may have registered providers before throwing. Remove those
            // partial registrations so it cannot appear healthy or shadow a later retry.
            val partialProviders = APIHolder.allProviders.filter { it.sourcePlugin == path }
            partialProviders.forEach { runCatching { APIHolder.removePluginMapping(it) } }
            APIHolder.allProviders.removeAll(partialProviders.toSet())
            extractorApis.removeAll(extractorApis.filter { it.sourcePlugin == path }.toSet())
            runCatching { classLoader?.close() }
            Logger.error("Impossible de charger l'extension $name (fichier=${file.name}, taille=${file.length()} octets)", t)
            states[name] = PluginState.Failed(failureSummary(t))
            // A failed conversion must not leave partial class files that look like a valid cache.
            runCatching { classesDir(name).deleteRecursively() }
            revision++
        }
    }

    /** Sites (providers) brought by an installed extension. */
    fun providersOf(internalName: String): List<com.lagradost.cloudstream3.MainAPI> {
        val path = loaded[internalName]?.file?.absolutePath ?: return emptyList()
        return providers.filter { it.sourcePlugin == path }
    }

    private fun unloadLocked(internalName: String) {
        val plugin = loaded.remove(internalName) ?: return
        runCatching { plugin.instance.beforeUnload() }
        val path = plugin.file.absolutePath
        val providers = APIHolder.allProviders.filter { it.sourcePlugin == path }
        providers.forEach { APIHolder.removePluginMapping(it) }
        APIHolder.allProviders.removeAll(providers.toSet())
        extractorApis.removeAll(extractorApis.filter { it.sourcePlugin == path }.toSet())
        runCatching { plugin.loader.close() }
        revision++
    }

    /** Translates classes.dex into a directory of .class files, cached by file hash. */
    private fun ensureConverted(cs3: File, dir: File): File {
        // Hash the archive as a stream: readBytes() duplicated the entire archive in heap
        // before dex2jar allocated its own intermediate structures.
        val digest = MessageDigest.getInstance("SHA-256")
        cs3.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        val marker = File(dir, ".source-hash")
        if (marker.exists() && marker.readText() == hash) return dir

        dir.deleteRecursively()
        dir.mkdirs()
        ZipFile(cs3).use { zip ->
            val dexEntries = zip.entries().toList().filter { it.name.matches(Regex("classes\\d*\\.dex")) }
            require(dexEntries.isNotEmpty()) { "Aucun classes.dex dans ${cs3.name}" }
            // DEX-to-JVM conversion can use several times the DEX size in heap. Reject
            // unusually large inputs before invoking dex2jar, which otherwise can exhaust
            // the app heap and destabilize Compose's UI thread.
            val totalDexBytes = dexEntries.sumOf { it.size.coerceAtLeast(0L) }
            require(dexEntries.size <= MAX_DEX_COUNT) {
                "Extension incompatible : plus de $MAX_DEX_COUNT fichiers DEX dans le package desktop"
            }
            require(dexEntries.all { it.size in 1..MAX_SINGLE_DEX_BYTES } && totalDexBytes <= MAX_TOTAL_DEX_BYTES) {
                "Extension trop volumineuse pour la conversion desktop (DEX > 32 Mo par fichier ou > 64 Mo au total)"
            }
            // dex2jar's peak heap can be multiple times the raw DEX payload. If the current
            // heap cannot plausibly fit that working set, reject this extension before OOM takes
            // down Compose scrolling or other providers. Run best-effort GC once before estimating.
            System.gc()
            val runtime = Runtime.getRuntime()
            val usedHeap = runtime.totalMemory() - runtime.freeMemory()
            val availableHeap = runtime.maxMemory() - usedHeap
            val estimatedWorkingSet = totalDexBytes * 10L + 192L * 1024 * 1024
            require(estimatedWorkingSet <= runtime.maxMemory() * 3 / 4 && availableHeap >= estimatedWorkingSet) {
                "Mémoire insuffisante pour convertir ${cs3.name} : besoin estimé ${estimatedWorkingSet / (1024 * 1024)} Mo, disponible ${availableHeap.coerceAtLeast(0) / (1024 * 1024)} Mo"
            }
            for (entry in dexEntries) {
                val dex = zip.getInputStream(entry).use { it.readBytes() }
                Dex2jar.from(dex)
                    .reUseReg(false)
                    .topoLogicalSort()
                    .skipDebug(false)
                    .optimizeSynchronized(true)
                    .skipExceptions(false)
                    // Kotlin uses names like `constructor-impl` that must survive the translation.
                    .dontSanitizeNames(true)
                    .to(dir.toPath())
            }
            // Keep non-code resources (manifest, assets) reachable through the class loader.
            zip.entries().toList()
                .filter { !it.isDirectory && !it.name.endsWith(".dex") }
                .forEach { entry ->
                    val out = File(dir, entry.name)
                    out.parentFile.mkdirs()
                    zip.getInputStream(entry).use { input -> out.outputStream().use { input.copyTo(it) } }
                }
        }
        marker.writeText(hash)
        return dir
    }
}

#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: A macOS .dmg must be packaged on macOS. This script is not a Linux cross-compiler." >&2
  exit 2
fi

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java 21 is required. Install a JDK 21, then retry." >&2
  exit 2
fi
JAVA_MAJOR="$(java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/java.specification.version/ {print $2; exit}')"
if [[ "$JAVA_MAJOR" == 1.* ]]; then JAVA_MAJOR="${JAVA_MAJOR#1.}"; fi
if [[ ! "$JAVA_MAJOR" =~ ^[0-9]+$ || "$JAVA_MAJOR" -lt 21 ]]; then
  echo "ERROR: Java 21 or newer is required. Detected: ${JAVA_MAJOR:-unknown}." >&2
  exit 2
fi

if [[ ! -x ./gradlew ]]; then
  echo "ERROR: Gradle wrapper ./gradlew is missing or not executable." >&2
  exit 2
fi

echo "==> CloudStreamPC $(grep -E '^version = ' build.gradle.kts | head -1 | cut -d'"' -f2)"
echo "==> Running project tests, then building the macOS DMG. First build requires network access for Gradle/dependencies."
./gradlew --no-daemon clean test packageDmg

DMG="$(find build/compose/binaries/main/dmg -maxdepth 1 -type f -name '*.dmg' -print -quit 2>/dev/null || true)"
if [[ -z "$DMG" ]]; then
  echo "ERROR: Gradle completed, but no .dmg was found under build/compose/binaries/main/dmg." >&2
  exit 3
fi

echo "SUCCESS: $ROOT/$DMG"

#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v kotlinc >/dev/null 2>&1 || { echo "ERROR: kotlinc is required for this standalone compatibility smoke test." >&2; exit 2; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/PreferencesSmoke.kt" <<'KOTLIN'
import android.content.Context
fun main(args: Array<String>) {
    val prefs = Context().getSharedPreferences("smoke-test", Context.MODE_PRIVATE)
    when (args.single()) {
        "write" -> check(prefs.edit().putString("string", "తెలుగు+English").putInt("int", 42).putLong("long", 123456789L).putFloat("float", 1.25f).putBoolean("bool", true).putStringSet("set", setOf("a", "", "hello,world")).commit())
        "read" -> {
            check(prefs.getString("string", null) == "తెలుగు+English")
            check(prefs.getInt("int", -1) == 42)
            check(prefs.getLong("long", 0) == 123456789L)
            check(prefs.getFloat("float", 0f) == 1.25f)
            check(prefs.getBoolean("bool", false))
            check(prefs.getStringSet("set", null) == setOf("a", "", "hello,world"))
        }
        else -> error("Expected write or read")
    }
    println("PASS: preferences ${args.single()}")
}
KOTLIN
kotlinc "$ROOT/src/main/kotlin/com/cloudstreampc/core/AppDirs.kt" "$ROOT/src/main/kotlin/android/content/Context.kt" "$TMP/PreferencesSmoke.kt" -include-runtime -d "$TMP/preferences-smoke.jar"
export CLOUDSTREAMPC_HOME="$TMP/data"
java -Dcloudstreampc.home="$CLOUDSTREAMPC_HOME" -jar "$TMP/preferences-smoke.jar" write
java -Dcloudstreampc.home="$CLOUDSTREAMPC_HOME" -jar "$TMP/preferences-smoke.jar" read
javap -s -classpath "$TMP/preferences-smoke.jar" android.content.Context | grep -F '(Ljava/lang/String;I)Landroid/content/SharedPreferences;' >/dev/null
echo 'PASS: getSharedPreferences JVM descriptor'

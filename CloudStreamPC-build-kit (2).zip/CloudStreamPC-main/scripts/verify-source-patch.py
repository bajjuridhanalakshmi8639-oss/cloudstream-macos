#!/usr/bin/env python3
"""Dependency-free static verification of the CloudStreamPC source patch."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    file = ROOT / path
    if not file.is_file():
        raise AssertionError(f"missing file: {path}")
    return file.read_text(encoding="utf-8")

def check(label: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(label)
    print(f"PASS: {label}")

plugin = read("src/main/kotlin/com/cloudstreampc/plugins/PluginManager.kt")
extensions = read("src/main/kotlin/com/cloudstreampc/ui/ExtensionsScreen.kt")
context = read("src/main/kotlin/android/content/Context.kt")
search = read("src/main/kotlin/com/cloudstreampc/ui/SearchScreen.kt")
main = read("src/main/kotlin/com/cloudstreampc/Main.kt")
home = read("src/main/kotlin/com/cloudstreampc/ui/HomeScreen.kt")
cloudflare = read("src/main/kotlin/com/lagradost/cloudstream3/network/CloudflareKiller.kt")
gradle = read("build.gradle.kts")
settings = read("src/main/kotlin/com/cloudstreampc/ui/SettingsPages.kt")
player = read("src/main/kotlin/com/cloudstreampc/player/ExternalPlayer.kt")
startup = read("src/main/kotlin/com/cloudstreampc/ui/Startup.kt")

check("extension installation is owned by an application SupervisorJob scope", "CoroutineScope(SupervisorJob() + Dispatchers.IO)" in plugin and "installScope.async(start = CoroutineStart.LAZY)" in plugin)
check("Extensions screen starts install before awaiting from UI scope", "PluginManager.startInstall(plugin, repoUrl)" in extensions and "installation.await()" in extensions)
check("ordinary UI cancellation is rethrown, not reported as an install failure", "catch (cancelled: CancellationException)" in extensions)
check("suspend manager loops propagate cancellation instead of swallowing it", plugin.count("catch (cancelled: CancellationException)") >= 4)
check("completed installs refresh the home cache even if the extension screen was hidden", "var installRevision by mutableIntStateOf(0)" in plugin and "HomeState.observedInstallRevision != installRevision" in home)
check("first-launch setup starts all app-owned install tasks and preserves cancellation", "plugins.map { plugin ->" in startup and "PluginManager.startInstall(plugin, defaultRepository.url)" in startup and "catch (cancelled: CancellationException)" in startup)
check("installation rollback retains old .cs3 until successful load", "backupFile.delete()" in plugin and "version précédente restaurée" in plugin)
check("extension download is streamed and size-capped before whole-archive allocation", "private suspend fun downloadExtension" in plugin and "body.byteStream().use" in plugin and "downloaded <= MAX_EXTENSION_ARCHIVE_BYTES" in plugin and "MAX_EXTENSION_ARCHIVE_BYTES = 100L * 1024 * 1024" in plugin)
check("DEX count and size limits exist", "MAX_SINGLE_DEX_BYTES = 32L * 1024 * 1024" in plugin and "MAX_TOTAL_DEX_BYTES = 64L * 1024 * 1024" in plugin and "MAX_DEX_COUNT = 8" in plugin and "val dexEntries = zip.entries().asSequence()" in plugin)
check("DEX working-set memory guard exists", "estimatedWorkingSet = totalDexBytes * 10L + 192L * 1024 * 1024" in plugin and "availableHeap >= estimatedWorkingSet" in plugin)
check("OOM conversion cleanup and concise diagnostic exist", "if (t is OutOfMemoryError) {" in plugin and "System.gc()" in plugin and "cache supprimé" in plugin)
check("SharedPreferences desktop method exists", "getSharedPreferences(name: String, mode: Int): SharedPreferences" in context)
check("extension preferences persist between process launches", "writeToDisk()" in context and "readFromDisk()" in context and "extension-preferences" in context and "ATOMIC_MOVE" in context)
check("repeat getSharedPreferences calls reuse one object per name", "instances.computeIfAbsent(name)" in context)
check("macOS DMG builder validates platform and runs tests", (ROOT / "scripts/build-macos-dmg.sh").is_file() and "uname -s" in (ROOT / "scripts/build-macos-dmg.sh").read_text() and "clean test packageDmg" in (ROOT / "scripts/build-macos-dmg.sh").read_text())
check("DialogFragment compatibility limitation is diagnosed", "androidx/fragment/app/DialogFragment" in plugin)
check("stale search generations and provider timeout are guarded", "SearchState.generation" in search and "withTimeoutOrNull(30_000)" in search)
check("startup auto health checks remain disabled", "ExtensionHealth.checkIfDue()" not in main)
check("Cloudflare prompt cooldown exists", "cooldown" in cloudflare.lower() and "120_000" in cloudflare)
check("packaged JVM heap arg is configured", '"-Xmx2g"' in gradle)
check("macOS player settings no longer claim mpv is bundled", "mpv (installation requise sur Mac)" in settings)
check("macOS missing-player error gives Homebrew guidance", "brew install mpv" in player and "/opt/homebrew/bin/mpv" in player)
print("PASS: all dependency-free source assertions completed")
